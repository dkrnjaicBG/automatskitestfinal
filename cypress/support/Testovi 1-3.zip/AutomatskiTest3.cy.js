//FINALNI TEST 3
/// <reference types="cypress"/>

describe("TreciZadatak", () => {
  //----------------------promenljive za selektore----------------------//
  let cart = [];
  let kolona1 = [
    //8 x
    "Stuffed veal with pomigrante",
    "Chicken with parsley",
    "Breaded Zuchinni with garlic sauce",
    "Skewered pork with Chives",
    "Mussels with oyster sauce",
    "Catfish with Dragon friit",
    "Mango Chicken",
    "Beef Gozleme",
  ];
  let kolona2 = [
    //5 x
    "Pancakes with strawberry cream",
    "Stawberry Sudnae",
    "Chocolate Mousse",
    "Malaga Cornetto",
    "Baklava with Vanilla Ice Cream",
  ];
  //---------------------------------OPEN-------------------------------//
  it("OtvoriStranicu", function () {
    cy.viewport(1920, 1080);
    cy.visit("http://10.15.1.204:3000/");
    cy.get(".nav-link[href='/menu']").click();
    cy.wait(1000);
    cy.title().should("eq", "QA Exam Kitchen");
    cy.url().should("include", "menu");
  });
  //-----------------------------VIDLJIVOST BUTTONA------------//
  // Cypress._.times(30, (o) => {
  it("Proveri vidljivost", function () {
    cy.viewport(1920, 1080);
    cy.visit("http://10.15.1.204:3000/menu");
    cy.scrollTo("bottom");
    cy.vidljivost(kolona1.concat(kolona2));
  });
  // });
  //-----------------------SELEKTOVANJE HRANE--------------------//
  Cypress._.times(3, (o) => {
    it.only("OdaberiHranu", function () {
      cy.viewport(1920, 1080);
      cy.visit("http://10.15.1.204:3000/menu");
      cy.scrollTo("bottom");
      cy.wait(1000);
      cy.izaberiHranu(kolona1);
      cy.izaberiHranu(kolona2);
      Cypress._.times(3, (k) => {
        let sviItemi = kolona1.concat(kolona2);
        cy.izaberiHranu(sviItemi, k);
      });

      Cypress._.times(5, (u) => {
        cy.get(`#listaItema>li`).each(($el, list, $list) => {
          for (let i = u; i < 6; i++) {
            if ($el == $list[i]) {
              // cy.izaberiHranu(sviItemi);
              let broj = Math.floor(Math.random() * (sviItemi.length - 1));
              cy.get(".text")
                .contains(sviItemi[broj])
                .parentsUntil(".menus")
                .find("[type='button']")
                .click({ force: true });
              cy.wait(3000);
            } else {
              cy.izaberiHranu(list);
              let broj = Math.floor(Math.random() * ($list.length - 1));
              cy.get(".text")
                .contains($list[broj])
                .parentsUntil(".menus")
                .find("[type='button']")
                .click({ force: true });
            }
          }
        });
      });
    });
  });
});
