//FINALNI TEST 2
describe("DrugiZadatak", () => {
  beforeEach(() => {
    cy.viewport(1920, 1080);
  });
  let randomBr;
  let randomString;
  //--------------Otvaranje zadatka--------------------//
  it("Otvori stranicu", function () {
    cy.visit("http://10.15.1.204:3000/");
    cy.get(".nav-link[href='/questionaire']").click();
    cy.wait(1000);
    cy.title().should("eq", "QA Exam Kitchen");
    cy.url().should("include", "questionaire");
  });
  //----------------------SVE LEVO KLIKTANJE (ezultat 9)----------------//
  it("Levi button test", function () {
    cy.visit("http://10.15.1.204:3000/questionaire");
    cy.wait(1000);
    let x = 0;
    for (randomBr = 1; randomBr < 18; randomBr += 2) {
      randomString = "#btn" + randomBr;
      cy.get(randomString).click();
      randomString = "#btn" + String(randomBr + 1);
      cy.get(randomString).click();
      let resultID = ".resultTest" + String((randomBr + 1) / 2);
      cy.daLiJeIsto(randomString, resultID);
      x++;
    }
    cy.get("#readmymind").click();
    cy.wait(1000);
    cy.proveraMenija(x);
  });
  //-------------SVE DESNO KLIKTANJE provera rezultat 0-------------------//
  it("Desni button test", function () {
    cy.visit("http://10.15.1.204:3000/questionaire");
    cy.wait(1000);
    let x = 0;
    for (randomBr = 2; randomBr <= 18; randomBr += 2) {
      randomString = "#btn" + randomBr;
      cy.get(randomString).click();
      randomString = "#btn" + String(randomBr - 1);
      cy.get(randomString).click();
      let resultID = ".resultTest" + String((randomBr + 1) / 2);
      cy.daLiJeIsto(randomString, resultID);
    }
    cy.get("#readmymind").click();
    cy.wait(1000);
    cy.proveraMenija(x);
  });
  //------------------------SVE KOMBINACIJE SLIKA I TEKSTA----------------//
  const NUM_OF_ANSWERS = 10;
  Cypress._.times(NUM_OF_ANSWERS, (k) => {
    it("Test za zbir " + String(k), function () {
      cy.visit("http://10.15.1.204:3000/questionaire");
      cy.wait(1000);
      let x = 0;
      for (randomBr = 1; randomBr < k * 2 + 1; randomBr += 2) {
        randomString = "#btn" + randomBr;
        cy.get(randomString).click();
        x++;
      }
      for (randomBr; randomBr <= 18; randomBr += 2) {
        randomString = "#btn" + String(randomBr + 1);
        cy.get(randomString).click();
      }
      cy.get("#readmymind").click();
      cy.wait(1000);
      cy.proveraMenija(x);
    });
  });
  //-------------------------------RANDOM-----------------------------------//
  it("Klikni random dugme", function () {
    cy.visit("http://10.15.1.204:3000/questionaire");
    cy.wait(1000);
    let x = 0;
    for (randomBr = 1; randomBr < 18; randomBr += 2) {
      let k = randomBr + Math.round(Math.random());
      randomString = "#btn" + k;
      cy.get(randomString).click();
      if (k % 2 == 1) {
        x++;
      }
    }
    cy.get("#readmymind").click();
    cy.wait(1000);
    cy.proveraMenija(x);
  });
});
