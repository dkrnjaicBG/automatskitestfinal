// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })

//ZADATAK 1
Cypress.Commands.add("radioButtonCheck", (selektovan, prvi, drugi) => {
  cy.get(selektovan)
    .should("be.visible")
    .should("be.enabled")
    .should("not.be.checked")
    .check()
    .should("be.checked");
  cy.get(prvi).should("not.be.checked");
  cy.get(drugi).should("not.be.checked");
});
Cypress.Commands.add("checkUncheck", function (a, b, c) {
  for (let i = b; i < c + 1; i++) {
    cy.get("#alg" + i)
      .should("be.visible")
      .should("be.enabled")
      .should("not.be.checked")
      .check()
      .uncheck();
  }
});
Cypress.Commands.add("localStorageCheck", function (key, string) {
  cy.window()
    .its("localStorage")
    .invoke("getItem", key)
    .should("be.equal", string);
});
Cypress.Commands.add("randomChecker", function (name) {
  let x = Math.round(Math.random());
  if (x == 1) {
    cy.get(name).check();
  }
});

//ZADATAK 2
Cypress.Commands.add("daLiJeIsto", function (button, polje) {
  cy.get(button).then(($btn) => {
    const txt = $btn.text();
    cy.get(polje).should(($rID) => {
      expect($btn.text()).to.eq(txt);
    });
  });
});
Cypress.Commands.add("proveraMenija", function (sum) {
  switch (sum) {
    case (0, 1):
      {
        cy.get("#recHeader").should("have.text", "Avocado Benedict");
        cy.get(".card-img-top[src='images/breakfast-6.jpg']").should(
          "be.visible"
        );
      }
      break;
    case (2, 3):
      {
        cy.get("#recHeader").should("have.text", "Strawberry Sundae");
        cy.get(".card-img-top[src='images/dessert-2.jpg']").should(
          "be.visible"
        );
      }
      break;
    case (4, 5):
      {
        cy.get("#recHeader").should("have.text", "Soy Salmon");
        cy.get(".card-img-top[src='images/dinner-4.jpg']").should("be.visible");
      }
      break;
    case (6, 7):
      {
        cy.get("#recHeader").should("have.text", "Culiflower Dipper");
        cy.get(".card-img-top[src='images/lunch-3.jpg']").should("be.visible");
      }
      break;
    case (8, 9):
      {
        cy.get("#recHeader").should("have.text", "Blonde");
        cy.get(".card-img-top[src='images/menu-1.jpg']").should("be.visible");
      }
      break;
  }
});

//ZADATAK 3
Cypress.Commands.add("izaberiHranu", function (array, k) {
  let broj = Math.floor(Math.random() * (array.length - 1));
  cy.get(".text")
    .contains(array[broj])
    .parentsUntil(".menus")
    .find("[type='button']")
    .click({ force: true });
  cy.wait(3000);
});
Cypress.Commands.add("vidljivost", function (array, k) {
  Cypress._.times(13, (p) => {
    cy.log("p+1=", p, "array[p+1]=", array[p]);
    cy.get(".text")
      .contains(array[p])
      .parentsUntil(".menus")
      .find("[type='button']")
      .should("be.enabled")
      .and("be.visible");
  });
});
