//FINALNI TEST 1
describe("PrviZadatak", () => {
  //-------------promenljive za koriscenje--------------//
  let randomBR;
  let randomString = "T " + Math.random().toString(36).substring(2);
  const overview = {
    cbr: "",
    org: randomString,
    age: "",
    dtr: "",
    tmr: "",
    gur: "",
    alr: "",
    alg: "",
  };
  //--------------Otvaranje zadatka--------------------//
  it("OtvoriStranicu", function () {
    cy.visit("/reserve");
    cy.get(".nav-link[href='/reserve']").click();
    cy.wait(1000);
    cy.title().should("eq", "QA Exam Kitchen");
    cy.url().should("include", "reserve");
  });
  //------------RadioButtonCheck sa YES selektovanim--------------------//
  it("Check/Uncheck Yes", function () {
    cy.get("#alg_y")
      .should("be.visible")
      .should("be.enabled")
      .should("not.be.checked")
      .check();
    cy.checkUncheck("#alg", 1, 6);
  });
  //------------RadioButtonCkeck sa MAYBE selektovanim------------------//
  it("Check/Uncheck Maybe", function () {
    cy.reload();
    cy.get("#alg_m")
      .should("be.visible")
      .should("be.enabled")
      .should("not.be.checked")
      .check();
    cy.checkUncheck("#alg", 1, 6);
  });
  it("popunjavanje forme", () => {
    //---------------------Random Popunjavanje forme----------------------//

    cy.visit("/reserve");
    cy.wait(2000);
    //ORGANIZATOR
    cy.get("#name[class='form-control org']")
      .should("be.visible")
      .should("be.enabled")
      .type(randomString);
    //BROJ GODINA SLAVLJENIKA
    randomString = "T " + Math.random().toString(36).substring(2);
    cy.get("#name[class='form-control bp']")
      .should("be.visible")
      .should("be.enabled")
      .type(randomString);

    overview.cbr = randomString;
    //Broj godina
    randomBR = Math.floor(Math.random() * 100 + 1);
    cy.get("#age").should("be.visible").should("be.enabled").type(randomBR);

    overview.age = String(randomBR);
    //Unos datuma (sa mogucnoscu 3 godine unapred rezervacije)
    var today = new Date();
    var dd = Math.floor(Math.random() * 31 + 1);
    if (dd < 10) {
      dd = "0" + dd;
    }
    var mm = Math.floor(Math.random() * 12 + 1);
    if (mm < 10) {
      mm = "0" + mm;
    }
    var yyyy = today.getFullYear() + Math.floor(Math.random() * 3);
    today = yyyy + "-" + mm + "-" + dd;
    overview.dtr = today;
    cy.get("#date").should("be.visible").should("be.enabled").type(today);
    let hh = Math.floor(Math.random() * 24);
    let min = Math.floor(Math.random() * 60);
    let curTime;
    if (hh < 10) {
      hh = "0" + hh;
    }
    if (min < 10) {
      min = "0" + min;
    }
    curTime = hh + ":" + min;
    cy.get("#time").type(curTime);

    overview.tmr = curTime;
    //Guests
    randomBR = Math.floor(Math.random() * 4 + 1);
    switch (randomBR) {
      case 1:
        {
          cy.get("#persons").select("2-5").should("have.value", "1");
          overview.gur = "2-5";
        }
        break;
      case 2:
        {
          cy.get("#persons").select("6-10").should("have.value", "2");
          overview.gur = "6-10";
        }
        break;
      case 3:
        {
          cy.get("#persons").select("11-20").should("have.value", "3");
          overview.gur = "11-20";
        }
        break;
      case 4:
        {
          cy.get("#persons").select("21+").should("have.value", "4");
          overview.gur = "21+";
        }
        break;
    }
    //Alergies
    randomBR = Math.floor(Math.random() * 3);
    switch (randomBR) {
      case 0:
        {
          //-------------Radio YES-------------------//
          cy.radioButtonCheck("#alg_y", "#alg_m", "#alg_n");
          cy.get("#alg_y").should("have.value", "Yes");
          overview.alr = "Yes";
          checkboxTrue();
        }
        break;
      case 1:
        {
          //--------------Radio NO------------------//
          cy.get("#alg_n").should("have.value", "No");
          cy.radioButtonCheck("#alg_n", "#alg_y", "#alg_m");
          overview.alr = "No";
          cy.get("#which").should(
            "have.class",
            "form-group grid-container disabled"
          );
        }
        break;
      case 2:
        {
          //--------------Radio Maybe------------------//
          cy.get("#alg_m").should("have.value", "Maybe");
          cy.radioButtonCheck("#alg_m", "#alg_y", "#alg_n");
          overview.alr = "Maybe";
          checkboxTrue();
        }
        break;
    }
    cy.get(".btn[href='#ex1']").click();
    //Overview Check
    cy.get("#orr").should("have.text", overview.org);
    cy.get("#agr").should("have.text", overview.age);
    cy.get("#tmr").should("have.text", overview.tmr);
    cy.get("#gur").should("have.text", overview.gur);
    cy.get("#alr").should("have.text", overview.alr);
    cy.get("#cbr").should("have.text", overview.cbr);
    //Local Storage Check
    cy.localStorageCheck("Organizer", overview.org);
    cy.localStorageCheck("Birthday_Person", overview.cbr);
    cy.localStorageCheck("Age", overview.age);
    cy.localStorageCheck("Date", overview.dtr);
    cy.localStorageCheck("Time", overview.tmr);
    cy.localStorageCheck("Number_Of_People", overview.gur);
  });
  function checkboxTrue() {
    for (let i = 1; i <= 6; i++) {
      cy.randomChecker("#alg" + i);
    }
  }
});
